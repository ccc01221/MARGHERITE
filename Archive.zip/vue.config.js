module.exports = {
    productionSourceMap: false,
};